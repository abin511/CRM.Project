﻿namespace CRM.Model
{
    public  class ParameterQuery
    {
        public int pageIndex { get; set; }

        public int pageSize { get; set; }

        public int total { get; set; }
    }
}
